﻿using Newtonsoft.Json;
using PruebaYTP.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace PruebaYTP.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> BuscarVideos(string idCanal)
        {
            YouTube yt = new YouTube();
            string urlApi = ConfigurationManager.AppSettings["UrlApi"];

            using (var cl = new HttpClient())
            {
                cl.BaseAddress = new Uri(urlApi);

                cl.DefaultRequestHeaders.Clear();
                cl.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage Response = await cl.GetAsync($"youtube/v3/search?order=date&part=snippet&q={idCanal.Replace(" ", "%20")}&maxResults=25&key=AIzaSyA_s167_5Kq2mnTTddXz26JzBEx6t3PIfY");

                


                if (Response.IsSuccessStatusCode)
                {
                    var ytResponse = Response.Content.ReadAsStringAsync().Result;

                    yt = JsonConvert.DeserializeObject<YouTube>(ytResponse);

                }

                return View("Index", yt);
            }
        }


    }
}