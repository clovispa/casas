﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaYTP.Models
{
    public class PageInfo
    {
        public int totalResults { get; set; }
        public int resultsPerPage { get; set; }
    }
}