﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaYTP.Models
{
    public class Item
    {
        public string kind { get; set; }
        public string etag { get; set; }
        public Id id { get; set; }
        public Snippet snippet { get; set; }
    }
}