﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaYTP.Models
{
    public class Id
    {
        public string kind { get; set; }
        public string videoId { get; set; }
        public string playlistId { get; set; }
    }
}