﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PruebaYTP.Models
{
    public class Thumbnails
    {
        public Default @default { get; set; }
        public Medium medium { get; set; }
        public High high { get; set; }
    }
}